**PLEASE DO NOT SUBMIT TOKEN ADDITIONS AS PULL REQUESTS**

All token requests should be made via an issue.
